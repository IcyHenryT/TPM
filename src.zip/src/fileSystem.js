const fs = require('fs')
async function write(fileName, newData) {
    const filePath = `./${fileName}.json`;
    if (fs.existsSync(filePath)) {
        const existingData = fs.readFileSync(filePath, 'utf8');
        let jsonData = JSON.parse(existingData);
        for (const key in newData) {
            if (!jsonData.hasOwnProperty(key)) {
                jsonData[key] = newData[key];
            }
        }
        fs.writeFile(filePath, JSON.stringify(jsonData, null, 2), 'utf8', (err) => {
            if (err) {
                console.error(`Error writing to ${fileName}.json:`, err);
                return;
            }
        });
    } else {
        fs.writeFile(filePath, JSON.stringify(newData, null, 2), 'utf8', (err) => {
            if (err) {
                console.error(`Error writing to ${fileName}.json:`, err);
                return;
            }
        });
    }
}

module.exports = {write}